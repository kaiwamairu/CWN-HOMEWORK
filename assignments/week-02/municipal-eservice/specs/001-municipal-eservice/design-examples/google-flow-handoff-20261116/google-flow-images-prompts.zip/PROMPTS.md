# Google Flow — Motion prompts

ใช้ภาพที่ตรงกับรหัสเป็น start frame และคัดลอก prompt ด้านล่าง

## 1A — หน้าเทศบาล — ใบไม้และธง

[เปิดภาพต้นฉบับ](1A-municipal-office.png)

```text
Locked-off camera. Animate the provided illustration with a gentle, clearly visible breeze: the outer tree branches and leaves sway naturally, and the Thai flag ripples smoothly around its fixed pole. The building, vehicles and people remain still. Preserve the original composition, warm watercolor texture, lighting, colors and crisp architectural details. Motion stays continuous and physically natural. Let the breeze complete a slow cycle and settle close to the starting pose for a looping website background. Keep the camera completely stationary throughout. Silent scene.
```

## 2A — ประชาชนกรอกแบบฟอร์ม

[เปิดภาพต้นฉบับ](2A-citizen-form.png)

```text
Locked-off camera. The man in the foreground writes two or three short strokes on the application form with natural, clearly visible movements of his fingers, wrist and pen. The pen tip remains in contact with the paper, while his other hand gently steadies the form. He then pauses and relaxes his writing hand close to its starting position. Preserve his identity, anatomy, desk, printed form layout and background. Keep the original watercolor texture, lighting and sharp details consistent throughout. The camera and framing remain completely fixed. Silent scene.
```

## 3A — เจ้าหน้าที่ตรวจเอกสาร

[เปิดภาพต้นฉบับ](3A-officer-review.png)

```text
Locked-off camera. The female municipal officer calmly scans the document she is holding, makes one small check-mark gesture with the pen on the form on her desk, then settles gently back into her original pose. Use natural, clearly visible finger and wrist movements. The held sheet flexes slightly and stays in the same hand throughout. Preserve her identity, anatomy, uniform, desk objects and the waiting citizen. Keep the original watercolor texture, colors, lighting and crisp details consistent. The camera and composition remain completely stationary. Silent scene.
```
